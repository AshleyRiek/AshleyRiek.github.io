//============================================================================
// Name        : VectorSorting.cpp
// Author      : Your name
// Version     : 1.0
// Copyright   : Copyright  2023 SNHU COCE
// Description : Vector Sorting Algorithms
//============================================================================

#include <algorithm>
#include <iostream>
#include <ctime>
#include <vector>
#include <string>
#include <chrono>  // For timing
#include "CSVparser.hpp"

using namespace std;
using namespace std::chrono;

// Define a structure to hold bid information
struct Bid {
    string title;
    string fund;
    string vehicle;
    double amount;
};


// -----------------------------
// Enhancement: instrumentation + additional algorithm
// Tracks algorithm behavior beyond runtime to support evidence-based comparisons.
// -----------------------------
struct SortMetrics {
    long long comparisons = 0;   // number of key comparisons
    long long swapsOrMoves = 0;  // swaps (in-place) or moves (merge)
    long long microseconds = 0;  // elapsed time
};

inline int compareTitles(const Bid& a, const Bid& b, SortMetrics* metrics) {
    if (metrics) { metrics->comparisons++; }
    return a.title.compare(b.title);
}

inline void countedSwap(Bid& a, Bid& b, SortMetrics* metrics) {
    if (metrics) { metrics->swapsOrMoves++; }
    std::swap(a, b);
}


// Display the bid information
void displayBid(Bid bid) {
    cout << bid.title << ": " << bid.amount << " | " << bid.fund << " | " << bid.vehicle << endl;
}

// Load a CSV file containing bids into a vector
vector<Bid> loadBids(string csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    vector<Bid> bids;
    csv::Parser file = csv::Parser(csvPath);

    // Loop to parse each row in the CSV file
    for (unsigned int i = 0; i < file.rowCount(); i++) {
        Bid bid;
        bid.title = file[i]["Title"];
        bid.fund = file[i]["Fund"];
        bid.vehicle = file[i]["Vehicle"];
        bid.amount = strtod(file[i]["Amount"].c_str(), nullptr);
        bids.push_back(bid);
    }

    return bids;
}

// Implement Selection Sort (instrumented)
void selectionSort(vector<Bid>& bids, SortMetrics* metrics = nullptr) {
    for (unsigned int i = 0; i < bids.size(); ++i) {
        unsigned int minIndex = i;

        // Find the minimum element based on bid.title
        for (unsigned int j = i + 1; j < bids.size(); ++j) {
            if (compareTitles(bids[j], bids[minIndex], metrics) < 0) {
                minIndex = j;
            }
        }

        // Swap the minimum element with the current element
        if (minIndex != i) {
            countedSwap(bids[i], bids[minIndex], metrics);
        }
    }
}


// Median-of-three pivot selection to reduce worst-case behavior on pre-sorted/patterned data
int medianOfThreeIndex(vector<Bid>& bids, int a, int b, int c, SortMetrics* metrics) {
    // Order a, b, c by title and return index of the median
    if (compareTitles(bids[a], bids[b], metrics) > 0) { std::swap(a, b); }
    if (compareTitles(bids[b], bids[c], metrics) > 0) { std::swap(b, c); }
    if (compareTitles(bids[a], bids[b], metrics) > 0) { std::swap(a, b); }
    return b;
}

// Partition function used in QuickSort (instrumented + median pivot)
int partition(vector<Bid>& bids, int begin, int end, SortMetrics* metrics = nullptr) {
    int mid = begin + (end - begin) / 2;
    int pivotIndex = medianOfThreeIndex(bids, begin, mid, end, metrics);
    countedSwap(bids[pivotIndex], bids[end], metrics); // move pivot to end

    Bid pivot = bids[end];  // Pivot element (now at end)
    int low = begin - 1;

    // Loop through the bids
    for (int i = begin; i < end; ++i) {
        if (compareTitles(bids[i], pivot, metrics) < 0) {
            ++low;
            countedSwap(bids[low], bids[i], metrics);
        }
    }

    // Swap the pivot element with the element at low + 1
    countedSwap(bids[low + 1], bids[end], metrics);
    return low + 1;
}


// Implement QuickSort (instrumented)
void quickSort(vector<Bid>& bids, int begin, int end, SortMetrics* metrics = nullptr) {
    if (begin >= end) {
        return;  // Base case: stop recursion
    }

    // Partition the vector and get the pivot index
    int pivotIndex = partition(bids, begin, end, metrics);

    // Recursively sort the left and right parts
    quickSort(bids, begin, pivotIndex - 1, metrics);
    quickSort(bids, pivotIndex + 1, end, metrics);
}



// Implement Merge Sort (instrumented)
// Stable O(n log n) sorting; uses additional memory for the merge buffer.
void merge(vector<Bid>& bids, int left, int mid, int right, vector<Bid>& buffer, SortMetrics* metrics) {
    int i = left;
    int j = mid + 1;
    int k = left;

    while (i <= mid && j <= right) {
        if (compareTitles(bids[i], bids[j], metrics) <= 0) {
            buffer[k++] = bids[i++];
        } else {
            buffer[k++] = bids[j++];
        }
        if (metrics) { metrics->swapsOrMoves++; } // count as move into buffer
    }

    while (i <= mid) {
        buffer[k++] = bids[i++];
        if (metrics) { metrics->swapsOrMoves++; }
    }
    while (j <= right) {
        buffer[k++] = bids[j++];
        if (metrics) { metrics->swapsOrMoves++; }
    }

    for (int idx = left; idx <= right; ++idx) {
        bids[idx] = buffer[idx];
        if (metrics) { metrics->swapsOrMoves++; } // move back to main vector
    }
}

void mergeSortRecursive(vector<Bid>& bids, int left, int right, vector<Bid>& buffer, SortMetrics* metrics) {
    if (left >= right) return;
    int mid = left + (right - left) / 2;
    mergeSortRecursive(bids, left, mid, buffer, metrics);
    mergeSortRecursive(bids, mid + 1, right, buffer, metrics);
    merge(bids, left, mid, right, buffer, metrics);
}

// Public entry
void mergeSort(vector<Bid>& bids, SortMetrics* metrics = nullptr) {
    if (bids.empty()) return;
    vector<Bid> buffer(bids.size());
    mergeSortRecursive(bids, 0, static_cast<int>(bids.size()) - 1, buffer, metrics);
}

// Display all bids in the list
void displayAllBids(vector<Bid>& bids) {
    for (unsigned int i = 0; i < bids.size(); ++i) {
        displayBid(bids[i]);
    }
}


// Run a sort on a copy of the vector so we can compare algorithms fairly
template<typename SortFn>
SortMetrics runInstrumentedSort(const vector<Bid>& original, SortFn sortFn) {
    vector<Bid> working = original;
    SortMetrics metrics;

    auto start = high_resolution_clock::now();
    sortFn(working, &metrics);
    auto end = high_resolution_clock::now();

    metrics.microseconds = duration_cast<microseconds>(end - start).count();
    return metrics;
}

void printMetricsRow(const string& name, const SortMetrics& m) {
    cout << name << " | "
         << "time: " << (m.microseconds / 1e6) << "s"
         << " | comps: " << m.comparisons
         << " | swaps/moves: " << m.swapsOrMoves
         << endl;
}

int main(int argc, char* argv[]) {
    // Declare variables
    vector<Bid> bids;
    string csvPath;
    int choice = 0;

    // Check for valid command-line arguments
    if (argc > 1) {
        csvPath = argv[1];
    }
    else {
        csvPath = "eBid_Monthly_Sales.csv";  // Default path
    }

    // Main loop
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. QuickSort All Bids (median-of-three pivot)" << endl;
        cout << "  5. Merge Sort All Bids" << endl;
        cout << "  6. Compare Sorting Algorithms (metrics)" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            auto start = high_resolution_clock::now();
            bids = loadBids(csvPath);
            auto end = high_resolution_clock::now();
            cout << bids.size() << " bids read" << endl;
            auto duration = duration_cast<microseconds>(end - start);
            cout << "time: " << duration.count() << " clock ticks" << endl;
            cout << "time: " << duration.count() / 1e6 << " seconds" << endl;
            break;
        }
        case 2: {
            displayAllBids(bids);
            break;
        }
        case 3: {
            auto start = high_resolution_clock::now();
            selectionSort(bids, nullptr);
            auto end = high_resolution_clock::now();
            cout << bids.size() << " bids sorted" << endl;
            auto duration = duration_cast<microseconds>(end - start);
            cout << "time: " << duration.count() << " clock ticks" << endl;
            cout << "time: " << duration.count() / 1e6 << " seconds" << endl;
            break;
        }
        case 4: {
            auto start = high_resolution_clock::now();
            if (!bids.empty()) { quickSort(bids, 0, static_cast<int>(bids.size()) - 1, nullptr); }
            auto end = high_resolution_clock::now();
            cout << bids.size() << " bids sorted" << endl;
            auto duration = duration_cast<microseconds>(end - start);
            cout << "time: " << duration.count() << " clock ticks" << endl;
            cout << "time: " << duration.count() / 1e6 << " seconds" << endl;
            break;
        }

        case 5: {
            auto start = high_resolution_clock::now();
            mergeSort(bids, nullptr);
            auto end = high_resolution_clock::now();
            cout << bids.size() << " bids sorted (merge sort)" << endl;
            auto duration = duration_cast<microseconds>(end - start);
            cout << "time: " << duration.count() << " clock ticks" << endl;
            cout << "time: " << duration.count() / 1e6 << " seconds" << endl;
            break;
        }
        case 6: {
            if (bids.empty()) {
                cout << "Load bids first (option 1) to run comparisons." << endl;
                break;
            }
            cout << "Comparing algorithms on the same dataset (sorting a copy each run):" << endl;

            auto sel = runInstrumentedSort(bids, [](vector<Bid>& v, SortMetrics* m){ selectionSort(v, m); });
            auto qk  = runInstrumentedSort(bids, [](vector<Bid>& v, SortMetrics* m){ if (!v.empty()) quickSort(v, 0, static_cast<int>(v.size()) - 1, m); });
            auto mg  = runInstrumentedSort(bids, [](vector<Bid>& v, SortMetrics* m){ mergeSort(v, m); });

            printMetricsRow("Selection Sort", sel);
            printMetricsRow("QuickSort (median pivot)", qk);
            printMetricsRow("Merge Sort", mg);

            cout << "Note: Selection sort is O(n^2); QuickSort and MergeSort are typically O(n log n)." << endl;
            break;
        }

        case 9: {
            cout << "Goodbye." << endl;
            break;
        }
        default:
            cout << "Invalid option." << endl;
        }
    }

    return 0;
}
