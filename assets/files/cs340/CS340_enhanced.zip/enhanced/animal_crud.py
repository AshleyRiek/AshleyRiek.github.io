"""
animal_crud.py
--------------

Enhanced CRUD wrapper for the Austin Animal Center (AAC) animals collection in MongoDB,
plus helper queries for Grazioso Salvare's dashboard filters.

Milestone Four Enhancements (CS 499 - Databases)
- Local-first connection support (defaults to mongodb://localhost:27017)
- Optional URI-based configuration (MONGO_URI / AAC_DB / AAC_COL environment variables)
- Input validation for create/update operations
- Optional index creation for faster filtering (create_indexes)
- Safer read() with optional projection and limit

Usage (local, no auth)
----------------------
>>> from animal_crud import AnimalShelter
>>> shelter = AnimalShelter()  # defaults to localhost:27017, db=AAC, col=animals
>>> shelter.create_indexes()
>>> print(len(shelter.read({})))

Usage (explicit URI)
--------------------
>>> shelter = AnimalShelter(uri="mongodb://localhost:27017", db="AAC", col="animals")
"""

from __future__ import annotations

import os
from typing import List, Dict, Any, Optional, Iterable

from pymongo import MongoClient, ASCENDING
from pymongo.errors import ConnectionFailure, PyMongoError


class AnimalShelter:
    """
    CRUD operations for the AAC animals collection in MongoDB.

    Parameters
    ----------
    uri : str, optional
        MongoDB connection URI. If omitted, uses env MONGO_URI or defaults to
        "mongodb://localhost:27017".
    username, password, host, port : optional
        Legacy/credential-based connection. If provided, a URI is constructed.
        (Kept for compatibility with older course environments.)
    db : str
        Database name. Default = env AAC_DB or "AAC".
    col : str
        Collection name. Default = env AAC_COL or "animals".
    """

    def __init__(
        self,
        uri: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        host: str = "localhost",
        port: int = 27017,
        db: Optional[str] = None,
        col: Optional[str] = None,
    ) -> None:
        self.db_name = db or os.getenv("AAC_DB", "AAC")
        self.col_name = col or os.getenv("AAC_COL", "animals")

        # Prefer explicit URI > env var > legacy credentials > localhost default
        if uri is None:
            uri = os.getenv("MONGO_URI")

        if uri is None:
            if username and password:
                # Legacy authenticated connection (kept for older labs)
                uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin"
            else:
                # Local, no-auth default
                uri = f"mongodb://{host}:{port}"

        try:
            self.client = MongoClient(uri)
            self.client.admin.command("ping")  # fail fast if connection is invalid
            self.database = self.client[self.db_name]
            self.collection = self.database[self.col_name]
        except ConnectionFailure as e:
            raise ConnectionFailure(f"Could not connect to MongoDB using '{uri}': {e}") from e

    # ------------------------------------------------------------------
    # VALIDATION HELPERS
    # ------------------------------------------------------------------

    @staticmethod
    def _is_nonempty_dict(data: Any) -> bool:
        return isinstance(data, dict) and len(data) > 0

    @staticmethod
    def _clean_strings(data: Dict[str, Any]) -> Dict[str, Any]:
        """Trim whitespace for any string fields to improve data consistency."""
        cleaned: Dict[str, Any] = {}
        for k, v in data.items():
            if isinstance(v, str):
                cleaned[k] = v.strip()
            else:
                cleaned[k] = v
        return cleaned

    # ------------------------------------------------------------------
    # PERFORMANCE HELPERS
    # ------------------------------------------------------------------

    def create_indexes(self) -> None:
        """
        Create indexes that support common dashboard filters.
        Safe to call multiple times.
        """
        try:
            # Single-field indexes for common filters
            self.collection.create_index([("breed", ASCENDING)])
            self.collection.create_index([("sex_upon_outcome", ASCENDING)])
            self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)])
            self.collection.create_index([("animal_type", ASCENDING)])

            # Compound indexes for the rescue queries (breed + sex + age)
            self.collection.create_index(
                [("breed", ASCENDING), ("sex_upon_outcome", ASCENDING), ("age_upon_outcome_in_weeks", ASCENDING)]
            )
        except PyMongoError as e:
            # Indexes are an optimization; dashboard can still function without them.
            print(f"[INDEX ERROR] {e}")

    # ------------------------------------------------------------------
    # CRUD METHODS
    # ------------------------------------------------------------------

    def create(self, data: Dict[str, Any]) -> bool:
        """Insert a single document into the collection."""
        if not self._is_nonempty_dict(data):
            return False
        data = self._clean_strings(data)
        try:
            result = self.collection.insert_one(data)
            return bool(result.acknowledged)
        except PyMongoError as e:
            print(f"[CREATE ERROR] {e}")
            return False

    def read(
        self,
        query: Dict[str, Any],
        projection: Optional[Dict[str, int]] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Read documents matching `query`.

        projection example: {"_id": 0, "breed": 1, "name": 1}
        """
        if query is None:
            query = {}
        try:
            cursor = self.collection.find(query, projection)
            if isinstance(limit, int) and limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError as e:
            print(f"[READ ERROR] {e}")
            return []

    def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> int:
        """Update all documents matching `query` with `new_values`."""
        if not self._is_nonempty_dict(query) or not self._is_nonempty_dict(new_values):
            return 0
        new_values = self._clean_strings(new_values)
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return int(result.modified_count)
        except PyMongoError as e:
            print(f"[UPDATE ERROR] {e}")
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """Delete all documents matching `query`."""
        if not self._is_nonempty_dict(query):
            return 0
        try:
            result = self.collection.delete_many(query)
            return int(result.deleted_count)
        except PyMongoError as e:
            print(f"[DELETE ERROR] {e}")
            return 0

    # ------------------------------------------------------------------
    # DASHBOARD QUERIES
    # ------------------------------------------------------------------

    def all_animals(self) -> List[Dict[str, Any]]:
        """Return all animal documents."""
        return self.read({})

    def water_rescue(self) -> List[Dict[str, Any]]:
        """Return animals eligible for water rescue training."""
        query = {
            "$and": [
                {"breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}},
                {"sex_upon_outcome": "Intact Female"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
            ]
        }
        return self.read(query)

    def mountain_wilderness(self) -> List[Dict[str, Any]]:
        """Return animals eligible for mountain/wilderness rescue."""
        query = {
            "$and": [
                {"breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
            ]
        }
        return self.read(query)

    def disaster_tracking(self) -> List[Dict[str, Any]]:
        """Return animals eligible for disaster/individual tracking."""
        query = {
            "$and": [
                {"breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}},
            ]
        }
        return self.read(query)
