Grazioso Salvare Dashboard Project
CS 305 – Secure Coding

Project Overview
This repository contains the final dashboard code and documentation for Project Two in CS 305. The project involved developing a secure, interactive dashboard using Python, Dash, and MongoDB to display animal shelter data. The dashboard integrates with a custom CRUD Python module developed in Project One, providing functionality for reading and filtering animal records based on Grazioso Salvare’s specific requirements.

Reflection
How do you write programs that are maintainable, readable, and adaptable?
To write maintainable, readable, and adaptable code, I follow principles like modularization, meaningful variable names, clear comments, and separation of concerns. In Project One, I built the AnimalShelter class as a dedicated CRUD module that cleanly separated database operations from the rest of the dashboard code. This structure allowed me to reuse the module directly in Project Two by simply importing the class and calling its methods. The advantage of this approach was improved organization and ease of debugging, as I could test and verify each component separately. I can reuse this CRUD module in future projects involving MongoDB or easily adapt it to other NoSQL databases by modifying only the class’s connection and query methods.

How do you approach a problem as a computer scientist?
I approach problems methodically by first analyzing the client’s requirements, breaking them into manageable components, and researching best practices for each part. For this project, I began by outlining the database schema and indexing strategy, then developed queries to retrieve relevant data. Once the backend was stable, I focused on building an interactive front end that visualized the data in meaningful ways for the client. Compared to previous courses, this project required deeper integration of backend and frontend components and stricter attention to security. In future projects, I would continue using modular development and test-driven development to meet diverse client needs efficiently.

What do computer scientists do, and why does it matter?
Computer scientists solve problems by designing and implementing software that processes data and performs tasks efficiently and securely. In this project, my work directly supported Grazioso Salvare’s mission by creating a dashboard that filters animals for adoption based on specific traits important to their operations. By enabling faster, data-driven decisions, my dashboard could help the company streamline rescue efforts and reduce time spent manually searching through records. This project reflects how computer scientists contribute to real-world impacts through thoughtful software design and problem-solving.
