"""
animal_crud.py
--------------

A simple CRUD wrapper for the Austin Animal Center (AAC) collection in MongoDB,
plus helper queries for Grazioso Salvare's dashboard filters.

Usage example
-------------
>>> from animal_crud import AnimalShelter
>>> shelter = AnimalShelter("aacuser", "AACpass2025!")
>>> results = shelter.read({})
>>> print(len(results))
"""

from typing import List, Dict, Any, Optional
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, PyMongoError


class AnimalShelter:
    """
    CRUD operations for the Animal collection in MongoDB.

    Parameters
    ----------
    username : str
        MongoDB user name (e.g., "aacuser").
    password : str
        MongoDB password (e.g., "AACpass2025!").
    host : str, optional
        Hostname of MongoDB server; default is Apporto host.
    port : int, optional
        Port of MongoDB server; default is Apporto port.
    db : str, optional
        Database name. Default = "AAC".
    col : str, optional
        Collection name. Default = "animals".
    """

    _DEFAULT_HOST = "nv-desktop-services.appoto.com"
    _DEFAULT_PORT = 34635

    def __init__(
        self,
        username: str,
        password: str,
        host: Optional[str] = _DEFAULT_HOST,
        port: Optional[int] = _DEFAULT_PORT,
        db: str = "AAC",
        col: str = "animals",
    ) -> None:
        try:
            uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin&directConnection=true"
            self.client = MongoClient(uri)
            self.client.admin.command("ping")  # Trigger immediate connection
            self.database = self.client[db]
            self.collection = self.database[col]
        except ConnectionFailure as e:
            raise ConnectionFailure(f"Could not connect to MongoDB: {e}") from e

    # ------------------------------------------------------------------
    # CRUD METHODS
    # ------------------------------------------------------------------

    def create(self, data: Dict[str, Any]) -> bool:
        """Insert a single document into the collection."""
        if not data:
            return False
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"[CREATE ERROR] {e}")
            return False

    def read(self, query: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Read documents matching `query`."""
        try:
            return list(self.collection.find(query))
        except PyMongoError as e:
            print(f"[READ ERROR] {e}")
            return []

    def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> int:
        """Update all documents matching `query` with `new_values`."""
        if not query or not new_values:
            return 0
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"[UPDATE ERROR] {e}")
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """Delete all documents matching `query`."""
        if not query:
            return 0
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"[DELETE ERROR] {e}")
            return 0

    # ------------------------------------------------------------------
    # GRAZIOSO-SPECIFIC FILTERS
    # ------------------------------------------------------------------

    def all_animals(self) -> List[Dict[str, Any]]:
        """Return all animal documents."""
        try:
            return list(self.collection.find({}))
        except PyMongoError as e:
            print(f"[ALL ANIMALS ERROR] {e}")
            return []

    def water_rescue(self) -> List[Dict[str, Any]]:
        """Return animals eligible for water rescue training."""
        query = {
            "$and": [
                {"breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}},
                {"sex_upon_outcome": "Intact Female"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        return self.read(query)

    def mountain_wilderness(self) -> List[Dict[str, Any]]:
        """Return animals eligible for mountain/wilderness rescue."""
        query = {
            "$and": [
                {"breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        return self.read(query)

    def disaster_tracking(self) -> List[Dict[str, Any]]:
        """Return animals eligible for disaster/individual tracking."""
        query = {
            "$and": [
                {"breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}}
            ]
        }
        return self.read(query)
